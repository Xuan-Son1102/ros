#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# =================================================================
# Node ROS: line_follower.py
# =================================================================
# Nhiệm vụ:
# 1. Subscribe (lắng nghe) topic ảnh từ webcam.
# 2. Sử dụng OpenCV để xử lý ảnh:
#    - Chuyển đổi sang ảnh xám (grayscale).
#    - Làm mờ ảnh để giảm nhiễu.
#    - Phân ngưỡng (thresholding) để làm nổi bật 2 vạch đen.
#    - Tính toán trọng tâm của đường đi (phần màu trắng giữa 2 vạch đen).
#    - Tính toán độ lệch (error) so với tâm khung hình.
# 3. Sử dụng bộ điều khiển PID để chuyển đổi độ lệch thành vận tốc góc.
# 4. Publish lệnh vận tốc ra topic /cmd_vel.

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError

class LineFollower:
    def __init__(self):
        """
        Hàm khởi tạo của class.
        """
        rospy.init_node('line_follower_node', anonymous=True)
        rospy.loginfo("Line Follower Node dang khoi dong...")

        # --- Khởi tạo các đối tượng cần thiết ---
        self.bridge = CvBridge()
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        # Lắng nghe topic ảnh từ node usb_cam
        self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback)
        
        self.twist = Twist()

        # --- Cấu hình bộ điều khiển PID ---
        self.Kp = 0.4       # Hệ số tỷ lệ
        self.Ki = 0.0005    # Hệ số tích phân
        self.Kd = 0.2       # Hệ số vi phân
        self.last_error = 0
        self.integral = 0

    def image_callback(self, msg):
        """
        Callback được gọi mỗi khi có ảnh mới từ webcam.
        """
        try:
            # Chuyển đổi message ROS Image thành ảnh OpenCV
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # Lấy kích thước ảnh
        h, w, d = cv_image.shape

        # --- 1. Cắt ảnh (Region of Interest - ROI) ---
        # Chỉ xử lý 1/3 phần dưới của ảnh, nơi có lane đường
        # [SỬA LỖI] Chuyển kết quả sang số nguyên (integer)
        search_top = int(2 * h / 3)
        search_bot = h
        # Cắt ảnh theo chiều dọc
        cv_image[0:search_top, 0:w] = 0
        cv_image[search_bot:h, 0:w] = 0

        # --- 2. Xử lý ảnh ---
        # Chuyển sang ảnh xám
        gray = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        # Làm mờ ảnh để giảm nhiễu
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        # Phân ngưỡng để tạo ảnh nhị phân (trắng/đen)
        # Các vạch đen sẽ trở thành màu đen (0), đường đi sẽ thành màu trắng (255)
        ret, thresh = cv2.threshold(blur, 60, 255, cv2.THRESH_BINARY_INV)

        # --- 3. Tìm trọng tâm của đường đi ---
        # Tính toán các moment của ảnh nhị phân
        M = cv2.moments(thresh)
        
        if M['m00'] > 0:
            # Tính tọa độ x của trọng tâm (cx)
            cx = int(M['m10'] / M['m00'])
            # Tính tọa độ y của trọng tâm (cy)
            cy = int(M['m01'] / M['m00'])
            
            # Vẽ một vòng tròn tại trọng tâm để debug
            cv2.circle(cv_image, (cx, cy), 5, (0, 0, 255), -1)

            # --- 4. Tính toán độ lệch và điều khiển ---
            # Độ lệch là khoảng cách từ trọng tâm tới giữa khung hình
            error = w / 2 - cx
            
            # Tính toán PID
            self.integral += error
            derivative = error - self.last_error
            self.last_error = error
            
            # Tính toán vận tốc góc (lái)
            turn = self.Kp * error + self.Ki * self.integral + self.Kd * derivative
            
            # Đặt vận tốc cho robot
            self.twist.linear.x = 0.15  # Tốc độ đi thẳng không đổi
            self.twist.angular.z = turn / 100.0 # Scale giá trị lái

            # Publish lệnh
            self.cmd_vel_pub.publish(self.twist)
        
        # Hiển thị ảnh đã xử lý để debug
        cv2.imshow("Processed Image", cv_image)
        cv2.imshow("Thresholded Image", thresh)
        cv2.waitKey(3)

    def run(self):
        """
        Hàm chính để giữ cho node chạy.
        """
        rospy.spin()
        # Đảm bảo đóng các cửa sổ OpenCV khi node tắt
        cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        follower = LineFollower()
        follower.run()
    except rospy.ROSInterruptException:
        pass

