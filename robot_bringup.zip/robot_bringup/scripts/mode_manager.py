#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# =================================================================
# Node ROS: mode_manager.py
# =================================================================
# Nhiệm vụ:
# 1. Lắng nghe tín hiệu từ tay cầm PS2 để nhận lệnh chuyển chế độ.
# 2. Lắng nghe lệnh vận tốc từ cả 3 chế độ:
#    - Manual (teleop_twist_joy)
#    - Navigation (move_base)
#    - Line Following (line_follower)
# 3. Dựa vào chế độ hiện tại, chọn và gửi lệnh vận tốc đúng tới robot.

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Joy

class ModeManager:
    def __init__(self):
        """
        Hàm khởi tạo của class.
        """
        rospy.init_node('mode_manager_node')
        
        # Danh sách các chế độ
        self.modes = ['MANUAL', 'NAVIGATION', 'LINE_FOLLOWING']
        # Bắt đầu ở chế độ MANUAL
        self.current_mode = 0
        
        # Publisher gửi lệnh vận tốc cuối cùng tới esp32_bridge
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
        
        # --- Subscribers ---
        # Lắng nghe tay cầm để chuyển chế độ
        rospy.Subscriber('/joy', Joy, self.joy_callback)
        # Lắng nghe lệnh từ chế độ Manual
        rospy.Subscriber('/teleop/cmd_vel', Twist, self.teleop_callback)
        # Lắng nghe lệnh từ chế độ Navigation
        rospy.Subscriber('/nav/cmd_vel', Twist, self.nav_callback)
        # Lắng nghe lệnh từ chế độ Line Following
        rospy.Subscriber('/line/cmd_vel', Twist, self.line_callback)
        
        # Biến để chống dội phím (chỉ nhận 1 lần nhấn)
        self.last_button_state = 0
        
        rospy.loginfo("Mode Manager da khoi dong. Che do hien tai: %s", self.modes[self.current_mode])
        rospy.loginfo("Nhan nut [SELECT] de chuyen che do.")

    def joy_callback(self, msg):
        """
        Callback được gọi khi có tín hiệu từ tay cầm.
        """
        # Sử dụng nút SELECT (index = 8) để chuyển chế độ
        mode_switch_button = msg.buttons[8]
        
        # Phát hiện khi nút được nhấn (chuyển từ 0 -> 1)
        if mode_switch_button == 1 and self.last_button_state == 0:
            # Chuyển sang chế độ tiếp theo, quay vòng lại nếu hết
            self.current_mode = (self.current_mode + 1) % len(self.modes)
            rospy.loginfo("Da chuyen sang che do: %s", self.modes[self.current_mode])
        
        self.last_button_state = mode_switch_button

    def teleop_callback(self, msg):
        # Nếu đang ở chế độ MANUAL, gửi lệnh từ tay cầm
        if self.current_mode == 0:
            self.cmd_vel_pub.publish(msg)

    def nav_callback(self, msg):
        # Nếu đang ở chế độ NAVIGATION, gửi lệnh từ move_base
        if self.current_mode == 1:
            self.cmd_vel_pub.publish(msg)

    def line_callback(self, msg):
        # Nếu đang ở chế độ LINE_FOLLOWING, gửi lệnh từ line_follower
        if self.current_mode == 2:
            self.cmd_vel_pub.publish(msg)
            
    def run(self):
        rospy.spin()

if __name__ == '__main__':
    manager = ModeManager()
    manager.run()

