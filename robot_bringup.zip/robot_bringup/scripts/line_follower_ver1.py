#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# =================================================================
# Node ROS: line_follower.py (Sử dụng thuật toán nâng cao)
# =================================================================
# Nhiệm vụ:
# 1. Nhận ảnh từ webcam qua topic ROS.
# 2. Áp dụng biến đổi góc nhìn (Bird's-eye view).
# 3. Lọc màu HSV để tách biệt lane đường.
# 4. Sử dụng thuật toán Histogram và Sliding Window để tìm lane.
# 5. Tính toán góc lái và chuyển đổi thành lệnh vận tốc cho robot.

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge, CvBridgeError

class LineFollowerAdvanced:
    def __init__(self):
        rospy.init_node('line_follower_node_advanced', anonymous=True)
        rospy.loginfo("Advanced Line Follower Node dang khoi dong...")

        self.bridge = CvBridge()
        self.cmd_vel_pub = rospy.Publisher('/line/cmd_vel', Twist, queue_size=1)
        self.image_sub = rospy.Subscriber('/usb_cam/image_raw', Image, self.image_callback)
        
        self.twist = Twist()
        self.prevLx = []
        self.prevRx = []

    def image_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(e)
            return

        # --- 1. Biến đổi góc nhìn (Bird's-eye View) ---
        # [QUAN TRỌNG] Các điểm này cần được cân chỉnh cho phù hợp với camera của bạn
        tl = (154, 194); bl = (4, 328)
        tr = (460, 191); br = (633, 336)
        
        pts1 = np.float32([tl, bl, tr, br])
        pts2 = np.float32([[0,0], [0,480], [640,0], [640,480]])
        
        M = cv2.getPerspectiveTransform(pts1, pts2)
        birdseye = cv2.warpPerspective(frame, M, (640,480))

        # --- 2. Lọc màu HSV ---
        hsv = cv2.cvtColor(birdseye, cv2.COLOR_BGR2HSV)
        # Các giá trị này dùng để lọc ra vạch kẻ màu đen
        lower_black = np.array([0, 0, 0])
        upper_black = np.array([180, 255, 40])
        mask = cv2.inRange(hsv, lower_black, upper_black)

        # --- 3. Histogram và Sliding Window ---
        histogram = np.sum(mask[mask.shape[0]//2:, :], axis=0)
        midpoint = int(histogram.shape[0]/2)
        left_base = np.argmax(histogram[:midpoint])
        right_base = np.argmax(histogram[midpoint:]) + midpoint

        y = 472
        lx, rx = [], []

        while y > 0:
            # Left threshold
            img = mask[y-40:y, left_base-50:left_base+50]
            contours, _ = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"]/M["m00"])
                    lx.append(left_base-50 + cx)
                    left_base = left_base-50 + cx

            # Right threshold
            img = mask[y-40:y, right_base-50:right_base+50]
            contours, _ = cv2.findContours(img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"]/M["m00"])
                    rx.append(right_base-50 + cx)
                    right_base = right_base-50 + cx
            y -= 40

        # Giữ giá trị cũ nếu không tìm thấy lane
        if len(lx) == 0: lx = self.prevLx
        else: self.prevLx = lx
        if len(rx) == 0: rx = self.prevRx
        else: self.prevRx = rx

        # --- 4. Tính toán và Gửi lệnh điều khiển ---
        if len(lx) > 0 and len(rx) > 0:
            lane_center = (left_base + right_base) / 2
            car_position = 320 # Tâm của ảnh
            
            # Tính toán độ lệch
            error = car_position - lane_center
            
            # Sử dụng một bộ điều khiển P đơn giản
            # Bạn có thể cần tinh chỉnh hệ số Kp (0.01) này
            Kp = 0.01
            angular_z = Kp * error
            
            # Đặt vận tốc cho robot
            self.twist.linear.x = 0.15  # Tốc độ đi thẳng không đổi
            self.twist.angular.z = -angular_z # Đảo dấu để robot lái đúng hướng

            self.cmd_vel_pub.publish(self.twist)

        # Hiển thị ảnh đã xử lý để debug
        cv2.imshow("Original", frame)
        cv2.imshow("Bird's Eye View", birdseye)
        cv2.imshow("Lane Mask", mask)
        cv2.waitKey(1)

    def run(self):
        rospy.spin()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    follower = LineFollowerAdvanced()
    follower.run()

