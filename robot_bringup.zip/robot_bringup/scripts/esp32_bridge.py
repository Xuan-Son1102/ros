#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# =================================================================
# Node ROS: esp32_bridge.py (Bản Nâng Cấp - Tự động kết nối lại)
# =================================================================
# Nhiệm vụ:
# 1. Subscribe /cmd_vel để nhận lệnh điều khiển.
# 2. Chuyển đổi lệnh thành tốc độ cho 2 bánh xe.
# 3. Gửi lệnh xuống ESP32 qua cổng Serial (UART).
# 4. [Mới] Tự động phát hiện mất kết nối và cố gắng kết nối lại.

import rospy
import serial
from geometry_msgs.msg import Twist
import time

class ESP32Bridge:
    def __init__(self):
        rospy.init_node('esp32_bridge_node', anonymous=True)
        rospy.loginfo("ROS-ESP32 Bridge Node dang khoi dong...")

        self.serial_port = rospy.get_param('~serial_port', '/dev/ttyUSB0')
        self.baud_rate = rospy.get_param('~baud_rate', 115200)
        self.wheel_base = rospy.get_param('~wheel_base', 0.34)
        self.wheel_radius = rospy.get_param('~wheel_radius', 0.05)
        self.max_driver_speed = rospy.get_param('~max_driver_speed', 2000)

        self.ser = None
        # Thử kết nối lần đầu khi khởi động
        self.connect()

        rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)
        rospy.loginfo("Da dang ky topic /cmd_vel. San sang nhan lenh.")

    def connect(self):
        """
        Hàm để thiết lập hoặc kết nối lại với ESP32.
        """
        if self.ser:
            self.ser.close()
        rospy.loginfo("Dang co gang ket noi voi ESP32 qua cong %s...", self.serial_port)
        try:
            self.ser = serial.Serial(self.serial_port, self.baud_rate, timeout=1)
            rospy.loginfo(">>> Da ket noi thanh cong voi ESP32! <<<")
            time.sleep(2) # Chờ ESP32 khởi động lại
            return True
        except serial.SerialException as e:
            rospy.logerr("Ket noi that bai: %s", e)
            self.ser = None
            return False

    def cmd_vel_callback(self, msg):
        """
        Callback được gọi mỗi khi có message mới trên topic /cmd_vel.
        """
        # Nếu chưa kết nối, bỏ qua
        if not self.ser or not self.ser.is_open:
            rospy.logwarn_throttle(5, "Chua ket noi voi ESP32, bo qua lenh.")
            return
            
        linear_vel = msg.linear.x
        angular_vel = msg.angular.z
        
        v_left_rads = (linear_vel - (angular_vel * self.wheel_base / 2.0)) / self.wheel_radius
        v_right_rads = (linear_vel + (angular_vel * self.wheel_base / 2.0)) / self.wheel_radius
        
        speed_left = int(v_left_rads * (self.max_driver_speed / 10.0))
        speed_right = int(v_right_rads * (self.max_driver_speed / 10.0))

        speed_left = max(min(speed_left, self.max_driver_speed), -self.max_driver_speed)
        speed_right = max(min(speed_right, self.max_driver_speed), -self.max_driver_speed)

        command = "L{},R{}\n".format(speed_left, speed_right)
        
        # In ra lệnh cuối cùng (giảm tần suất để đỡ rối mắt)
        rospy.loginfo_throttle(1, "Sending to ESP32: %s", command.strip())
        
        try:
            self.ser.write(command.encode('utf-8'))
        except serial.SerialException as e:
            rospy.logerr("Loi khi gui du lieu: %s. Ngat ket noi.", e)
            # Đóng cổng bị lỗi và đặt self.ser = None để kích hoạt cơ chế kết nối lại
            if self.ser:
                self.ser.close()
            self.ser = None

    def run(self):
        """
        Hàm chính để giữ cho node chạy và xử lý kết nối lại.
        """
        rate = rospy.Rate(1) # Tần suất kiểm tra kết nối: 1 lần/giây
        while not rospy.is_shutdown():
            # Nếu kết nối bị mất (self.ser là None hoặc đã bị đóng)
            if not self.ser or not self.ser.is_open:
                rospy.logwarn("Mat ket noi voi ESP32. Dang thu ket noi lai...")
                self.connect()
            rate.sleep()
        
        # Dọn dẹp khi tắt node
        if self.ser and self.ser.is_open:
            rospy.loginfo("Dang dong cong Serial.")
            self.ser.close()

if __name__ == '__main__':
    try:
        bridge = ESP32Bridge()
        bridge.run()
    except rospy.ROSInterruptException:
        pass

